"""
core/simulator.py
=================
Time-series simulation engine for UDT-DIE.

Applies temporal patterns (daily cycles, seasonality, lag effects) to a base
DataFrame produced by core/generator.py.  All operations are fully vectorised.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Optional


# ---------------------------------------------------------------------------
# Daily pattern
# ---------------------------------------------------------------------------

def apply_daily_pattern(df: pd.DataFrame, traffic_col: str = "traffic") -> pd.DataFrame:
    """
    Reinforce or adjust the diurnal shape on an hourly traffic DataFrame.

    Adds a sine-based morning/evening peak factor on top of existing values,
    ensuring midnight continuity (the sine is 2π-periodic so it wraps cleanly).

    Parameters
    ----------
    df : pd.DataFrame
        Must contain a 'datetime' column (or DatetimeIndex) and `traffic_col`.
    traffic_col : str
        Name of the column to modify.

    Returns
    -------
    pd.DataFrame
        Copy of `df` with the `traffic_col` column updated.

    Edge cases
    ----------
    - Wrap-around is guaranteed because sin(2π·h/24) is naturally periodic.
    - Output traffic is clipped ≥ 0.
    """
    df = df.copy()

    # Resolve the hour-of-day from either a column or the index
    if "datetime" in df.columns:
        hours = pd.to_datetime(df["datetime"]).dt.hour.to_numpy()
    elif isinstance(df.index, pd.DatetimeIndex):
        hours = df.index.hour.to_numpy()
    else:
        raise ValueError("DataFrame must have a 'datetime' column or DatetimeIndex.")

    # Dual-peak rush-hour modifier (purely additive sine blend)
    morning = np.exp(-0.5 * ((hours - 8)  / 2.5) ** 2)
    evening = np.exp(-0.5 * ((hours - 18) / 2.5) ** 2)
    modifier = 1.0 + 0.3 * (morning + evening)   # gentle second pass

    df[traffic_col] = (df[traffic_col].to_numpy() * modifier).clip(min=0)
    return df


# ---------------------------------------------------------------------------
# Seasonality
# ---------------------------------------------------------------------------

def apply_seasonality(
    df: pd.DataFrame,
    value_col: str,
    amplitude: float = 0.15,
    date_col: Optional[str] = "date",
) -> pd.DataFrame:
    """
    Scale a time-series column by an annual sinusoidal seasonality factor.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain a date column (or DatetimeIndex).
    value_col : str
        Column whose values are to be scaled.
    amplitude : float
        Fractional amplitude of the seasonal swing (0.15 → ±15 %).
    date_col : str or None
        Name of the date column; pass None to use the DatetimeIndex.

    Returns
    -------
    pd.DataFrame
        Copy with `value_col` seasonally adjusted.

    Edge cases
    ----------
    - Handles year wrap-around because sin is periodic.
    - Negative values are clipped to 0 after scaling.
    """
    df = df.copy()

    if date_col and date_col in df.columns:
        dates = pd.to_datetime(df[date_col])
    elif isinstance(df.index, pd.DatetimeIndex):
        dates = df.index
    else:
        raise ValueError("Provide a valid date_col or a DatetimeIndex.")

    day_of_year = dates.day_of_year.to_numpy()
    seasonal_factor = 1.0 + amplitude * np.sin(2 * np.pi * (day_of_year - 80) / 365)

    df[value_col] = (df[value_col].to_numpy() * seasonal_factor).clip(min=0)
    return df


# ---------------------------------------------------------------------------
# Lag features
# ---------------------------------------------------------------------------

def add_lagged_features(
    df: pd.DataFrame,
    col: str,
    lag: int = 24,
    fill_value: float = np.nan,
) -> pd.DataFrame:
    """
    Create a lagged copy of `col` using np.roll, then optionally fill the
    wrap-around positions.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    col : str
        Column to lag.
    lag : int
        Number of positions to shift forward.  Negative values shift backward.
    fill_value : float
        Value to place in the positions that "wrapped around" (default: NaN).

    Returns
    -------
    pd.DataFrame
        Copy with new column `{col}_lag{lag}`.

    Edge cases
    ----------
    - lag == 0 → lagged column equals original.
    - Wrap-around positions are filled with `fill_value` (not circular data).
    """
    df = df.copy()
    values = df[col].to_numpy(dtype=float)
    rolled = np.roll(values, shift=lag)

    # Replace the wrap-around tail/head with fill_value
    if lag > 0:
        rolled[:lag] = fill_value
    elif lag < 0:
        rolled[lag:] = fill_value

    df[f"{col}_lag{lag}"] = rolled
    return df


# ---------------------------------------------------------------------------
# Weekly cycle helper
# ---------------------------------------------------------------------------

def apply_weekly_pattern(
    df: pd.DataFrame,
    traffic_col: str = "traffic",
    weekend_factor: float = 0.80,
) -> pd.DataFrame:
    """
    Reduce traffic on weekends by `weekend_factor`.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain a 'datetime' column or DatetimeIndex.
    traffic_col : str
        Column to modify.
    weekend_factor : float
        Multiplier applied on Saturday (5) and Sunday (6).

    Returns
    -------
    pd.DataFrame
        Copy with weekend traffic reduced.
    """
    df = df.copy()

    if "datetime" in df.columns:
        dow = pd.to_datetime(df["datetime"]).dt.dayofweek.to_numpy()
    elif isinstance(df.index, pd.DatetimeIndex):
        dow = df.index.dayofweek.to_numpy()
    else:
        raise ValueError("DataFrame must have a 'datetime' column or DatetimeIndex.")

    is_weekend = (dow >= 5).astype(float)
    factor = 1.0 - (1.0 - weekend_factor) * is_weekend
    df[traffic_col] = (df[traffic_col].to_numpy() * factor).clip(min=0)
    return df
